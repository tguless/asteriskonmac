<?php echo sha1($argv[1]); ?>
