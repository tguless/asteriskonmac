# asterisk

[<img src="https://img.shields.io/docker/automated/flaviostutz/asterisk"/>](https://hub.docker.com/r/flaviostutz/asterisk)

Asterisk container with common components installed

Use this a a base for other containers that needs an Asterisk installation
